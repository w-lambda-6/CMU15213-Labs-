#include "cachelab.h"
#include <stddef.h>
#include <stdio.h>
// as we need to read from a file
#include <stdlib.h>
#include <string.h>


// some relevant global variables
int verbose = 0;
int hit_count = 0, miss_count = 0, eviction_count = 0;
int s = -1, E = -1, b = -1;
int timestamp = 0;      // used for lru cache replacement policy
char operation;
unsigned long address;  // used to store the address from the trace
                        // we use this type as addresses are 64 bit
int size;
FILE* traceFile;


//defining the cache line structure
struct line{
    int valid;
    int tag;
    int last_used_time; // used for LRU replacement policy
    // no need to store byte blocks as they are useless
};

// defining the cache structure
typedef struct line* set;

// the global variable cache
set* cache;





void simulateCache(unsigned long address, int is_modify){
    // getting the set and the tag from address
    int set_pos = address >> b & ((1<<s)-1);
    int tag = address >> (b+s);

    set cur_set = cache[set_pos];
    int lru_pos = 0, lru_time = cur_set[0].last_used_time;  // used to track smallest last used time
                                                            // also used to find the line to evict
    for (int i = 0; i < E; i++){
        // cache hit
        if (cur_set->tag == tag){
            hit_count++;
            hit_count += is_modify;
            cur_set[i].last_used_time = timestamp;
            if(verbose) {
                printf("hit\n");
            }
            return;
        }

        // cache miss
        if (cur_set[i].last_used_time < lru_time){
            lru_time = cur_set[i].last_used_time;
            lru_pos = i;
        }
    }

    // cache miss
    miss_count++;
    // extra hit for modify after evicting victim
    hit_count += is_modify;

    // checks for cold misses, if cache empty at the start
    // then no eviction is counted
    eviction_count += (lru_time != -1);
    if (verbose){
        if (lru_time != -1){
            if (is_modify){
                printf("miss eviction hit\n");
            } else {
                printf("miss eviction\n");
            }
        } else {
            printf("miss\n");
        }
    }
    
    // eviction
    cur_set[lru_pos].last_used_time = timestamp;
    cur_set[lru_pos].tag = tag;
    return;
}


// function that displays help information
void printHelp(){
    printf("Usage: ./csim-ref [-hv] -s <s> -E <E> -b <b> -t <tracefile>\n");
    printf("-h:             Optional help flag that prints usage info\n");
    printf("-v:             Optional verbose flag that displays trace info\n");
    printf("-s <s>:         Number of set index bits (S = 2s is the number of sets)\n");
    printf("-E <E>:         Associativity (number of lines per set)\n");
    printf("-b <b>:         Number of block bits (B = 2b is the block size)\n");
    printf("-t <tracefile>: Name of the valgrind trace to replay\n");
}

// pass in argc and argv as we need to read flags from console input pretty simple as that
int main(int argc, char* argv[])
{
    // parsing the inputs
    for (int i = 0; i < argc; i++){
        // user needs help on usage, return immediately
        if (strcmp(argv[i], "-h")==0){
            printHelp();
            return 0;
        }

        if (strcmp(argv[i], "-v")){
            verbose = 1;
        }else if (strcmp(argv[i], "-s")==0){
            if (i + 1 < argc){
                s = atoi(argv[i+1]);
                i++;
            } else {
                printf("Error: -s requires a value\n");
                return 1;
            }
        }else if (strcmp(argv[i], "-E")==0){
            if (i + 1 < argc){
                E = atoi(argv[i+1]);
                i++;
            } else {
                printf("Error: -E requires a value\n");
                return 1;
            }
        }else if (strcmp(argv[i], "-b")==0){
            if (i + 1 < argc){
                b = atoi(argv[i+1]);
                i++;
            } else {
                printf("Error: -b requires a value\n");
                return 1;
            }
        }else if(strcmp(argv[i], "-t")==0){
            if (i+1<argc){
                traceFile = fopen(argv[i+1], "r");
                i++;
            }else{
                printf("Error: -t requires a file name\n");
                return 1;
            }
        }

        // checking if the input is valid or not
        if (s <= 0 || E <= 0 || b <= 0 || s+b > 64 || traceFile == NULL){
            printHelp();
            return 1;
        }
    }

    // initialising the cache
    cache = (set*)malloc(sizeof(set)*(1<<s));
    for (int i = 0; i < (1<<s); i++){
        cache[i] = (set)malloc(sizeof(struct line)*E);
        for (int j = 0; j < E; j++){
            cache[i][j].valid = -1;
            cache[i][j].tag = -1;
            cache[i][j].last_used_time = -1;    // better than initialising to 0 as can help tell
                                                // whether a cache line has been used or not
        }
    }

    while(fscanf(traceFile, "%s %lx %d\n", &operation, &address, &size)==3){
        // we increment the timestamp after every instruction
        timestamp++;
        if (verbose){
            printf("%c %lx %d", operation, address, size);
        }
        switch(operation){
            case 'I':
                continue;
            case 'M':
                simulateCache(address, 1);
                break;
            case 'L':   // load
            case 'S':
                simulateCache(address, 1);
        }
    }


    // remember to free memory before returning
    free(cache);
    printSummary(hit_count, miss_count, eviction_count);
    return 0;
}
