#include <stdio.h>
#include "csapp.h"
#include "cache.h"
/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

//self-defined structs
typedef char string[MAXLINE];
typedef struct{
    string host;
    string port;
    string path;
} url_t;

// self-defined function prototypes
void* thread(void* vargp);
void do_get(rio_t* client_rio_p, string url);
int parse_url(string url, url_t* url_info);
int parse_header(rio_t* client_rio_p, string header_info, string host);

/**
 * thread: create a separate thread to handle
 * requests achieveing parrallelism
 * @param vargp, pointer to client side socket descriptor
 */
void* thread(void* vargp){
    // don't use wrapper functions as errors when executing wrapper 
    // function will call exit(0) stopping the entire process
    // detach the thread
    pthread_detach(pthread_self());

    // store local variables into thread stack, free allocated memory
    // to prevent memory leaks
    int client_fd = *((int *)vargp);
    free(vargp);

    // initialise client side rio buffer
    rio_t client_rio;
    string buf;
    rio_readinitb(&client_rio, client_fd);

    // read client side content up to buf
    if (Rio_readlineb(&client_rio, buf, MAXLINE)<=0){
        fprintf(stderr, "Read request line error: %s\n", strerror(errno));
        close(client_fd);
        return NULL;
    }

    // parse the request line
    string method, url, http_version;
    if (sscanf(buf, "%s %s %s", method, url, http_version) != 3){
        fprintf(stderr, "Parse request line error: %s\n", strerror(errno));
        close(client_fd);
        return NULL;
    }

    // check if it is GET method or not
    if (!strcasecmp(method, "GET")){
        do_get(&client_rio, url);
    }
    // close the connection
    close(client_fd);
    return NULL;
}


/**
 * @param url, the request url
 * @param url_info, the place to store the parsed url result
 */
int parse_url(string url, url_t* url_info){
    // check if HTTP protocol or not
    const int http_prefix_len = strlen("http://");
    if (strncasecmp(url, "http://", http_prefix_len)){
        fprintf(stderr, "Not http protocol: %s\n", url);
        return -1;
    }

    // check if legal url
    char* host_start = url+http_prefix_len;
    char* port_start = strchr(host_start, ':');
    char* path_start = strchr(host_start, '/');

    // illegal url
    if (path_start == NULL) return -1;

    // if no port number is provided default port number is 80
    if (port_start == NULL){
        // set to null terminator to prevent copying extra info
        *path_start = '\0';
        strcpy(url_info->host, host_start);
        strcpy(url_info->port, "80");
        *path_start = '/';
        strcpy(url_info->path, path_start);
    }
    // port number provided
    else {
        *port_start = '\0';
        strcpy(url_info->host, host_start);
        *port_start = ':';
        *port_start = '\0';
        strcpy(url_info->port, port_start+1);
        *path_start = '/';
        strcpy(url_info->path, path_start);
    }

    return 0;
}


/**
 * @param client_rio_p, points to client side rio ptr
 * @param header_info, the place to store the parsing results
 * @param host, host value formerly parsed set as default for Host header
 */
int parse_header(rio_t* client_rio_p, string header_info, string host){
    string buf;
    int has_host_flag = 0;
    while(1){
        rio_readlineb(client_rio_p, buf, MAXLINE);
        // meets the finishing line
        if (strcmp(buf, "\r\n")==0) break;

        // meets Host header, record it and never add it later on
        if (!strncasecmp(buf, "Host:", strlen("Host: "))){
            has_host_flag = 1;
        }
        // skip Connection, Proxy-Connection, User-Agent headers
        // will set to default values later on
        if (!strncasecmp(buf, "Connection:", strlen("Connection:"))) continue;
        if (!strncasecmp(buf, "Proxy-Connection:", strlen("Proxy-Connection:"))) continue;
        if (!strncasecmp(buf, "User-Agent:", strlen("User-Agent:"))) continue;

        // other headers are directly added
        strcat(header_info, buf);
    }
    // we add a host header if there is none
    if (!has_host_flag){
        sprintf(buf, "Host: %s\r\n", host);
        strcpy(header_info, buf);
    }

    // adding connection, proxy-connection and user-agent headers
    strcat(header_info, "Connection: close\r\n");
    strcat(header_info, "Proxy-Connection: close\r\n");
    strcat(header_info, user_agent_hdr);
    // add finishing line
    strcat(header_info, "\r\n");
    return 0;
}


/**
 * handling GET requests
 * @param client_rio_p, points to client side rio
 * @param url, the request url
 */
void do_get(rio_t* client_rio_p, string url){
    // check if the request url is in cache or not
    if (query_cache(client_rio_p, url)) return;

    // parse the url
    url_t url_info;
    if (parse_url(url, &url_info)<0){
        fprintf(stderr, "Parse url error\n");
        return;
    }

    // parse the header
    string header_info;
    parse_header(client_rio_p, header_info, url_info.host);

    // start up connection with host without using wrappers to prevent (exit(0))
    int server_fd = open_clientfd(url_info.host, url_info.port);
    if (server_fd < 0){
        fprintf(stderr, "Open connect to %s:%s error\n", url_info.host, url_info.port);
        return;
    }

    // initialise server side buffer rio
    rio_t server_rio;
    rio_readinitb(&server_rio, server_fd);

    // prepare the request line and request header
    string buf;
    sprintf(buf, "GET %s HTTP/1.0\r\n%s", url_info.path, header_info);

    // sending out request line and request header
    if (rio_writen(server_fd, buf, strlen(buf)) != strlen(buf)){
        fprintf(stderr, "Send request line and header error\n");
        close(server_fd);
        return;
    }

    // receive response line
    int resp_total = 0, resp_current = 0;
    char file_cache[MAX_OBJECT_SIZE];
    int client_fd = client_rio_p->rio_fd;

    // read response from server side
    // server might write multiple times, so we need to read in 
    // a loop until meeting EOF(resp_current == 0)
    while((resp_current = rio_readnb(&server_rio, buf, MAXLINE))){
        if (resp_current < 0) {
            fprintf(stderr, "Read server response error\n");
            close(server_fd);
            return;
        }

        // caching into local variable file_cache, prepare to
        // be used in caching
        if (resp_total + resp_current < MAX_OBJECT_SIZE){
            memcpy(file_cache+resp_total, buf, resp_current);
        }
        resp_total += resp_current;
        // send to the client side
        if (rio_writen(client_fd, buf, resp_current)!=resp_current){
            fprintf(stderr, "Send response to client error\n");
            close(server_fd);
            return;
        }
    }

    // if response is less than MAX_OBJECT_SIZE, cache locally
    if (resp_total < MAX_OBJECT_SIZE){
        add_cache(url, file_cache, resp_total);
    }
    close(server_fd);
    return;
}



int main(int argc, char** argv)
{
    // block SIGPIPE signals to maintain robustness
    // as this will be triggered when we write to a 
    // connection that has been closed
    signal(SIGPIPE, SIG_IGN);

    int listenfd, * connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    pthread_t tid;

    // check if input is valid or not
    if (argc != 2){
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(1);
    }

    // create listening socket, we can use wrapper functions here
    // as we are supposed to exit(0) if there is an error
    listenfd = Open_listenfd(argv[1]);

    init_cache();
    // listen for requests within loops
    while(1){
        clientlen = sizeof(clientaddr);

        // use malloc not local variables to avoid
        // conflict between threads
        connfd = (int*)malloc(sizeof(int));
        
        // don't use Accept wrapper function to avoid exit(0)
        *connfd = accept(listenfd, (SA*)&clientaddr, &clientlen);
        if (*connfd < 0){
            fprintf(stderr, "Accept Error: %s\n", strerror(errno));
            continue;
        }
        //create a new thread to handle the request
        pthread_create(&tid, NULL, thread, connfd);
    }

    close(listenfd);
}
