#include "csapp.h"
#include "cache.h"

// global variables
static cache_t cache;
// semaphores prioritises readers, global thread level parallel lock
static sem_t mutex, w;
// thread shared variables
static int readcnt, timestamp;

void init_cache(){
    timestamp = 0;
    readcnt = 0;
    cache.using_cache_num = 0;
    sem_init(&mutex, 0, 1);
    sem_init(&w, 0, 1);
}


/**
 * query_cache: queries information about the cache
 * @param rio_p: rio pointer used to acquire client socket descriptor
 * @param url: the request url
 */
int query_cache(rio_t* rio_p, string url){
    P(&mutex);
    readcnt++;
    if (readcnt == 1) P(&w);
    V(&mutex);

    // looks for url in the cache
    int hit_flag = 0;
    for (int i = 0; i < MAX_CACHE_NUM; i++){
        // cache hit
        if (!strcmp(cache.cache_files[i].url, url)){
            // update the timestamp, as it is global variable
            // we need to acquire the lock first
            P(&mutex);
            cache.cache_files[i].timestamp = timestamp++;
            V(&mutex);
            // send the cache contents
            rio_writen(rio_p->rio_fd, cache.cache_files[i].content, cache.cache_files[i].content_size);
            hit_flag = 1;
            break;
        }
    }

    P(&mutex);
    readcnt--;
    if (readcnt==0){
        V(&w);
    }
    V(&mutex);
    if (hit_flag) return 1;
    return 0;
}

int add_cache(string url, char* content, int content_size){
    // only one writer allowed each time to modify cache
    P(&w);

    // checks if the cache is full or not
    // cache is full
    if (cache.using_cache_num = (MAX_CACHE_NUM-1)){
        // find the oldest cache line
        int oldestIndex;
        int oldestTimeStamp = timestamp;
        for (int i= 0; i < MAX_CACHE_NUM; i++){
            if (cache.cache_files[i].timestamp < oldestTimeStamp){
                oldestTimeStamp = cache.cache_files[i].timestamp;
                oldestIndex = i;
            }
        }

        // replace the cache line
        strcpy(cache.cache_files[oldestIndex].url, url);
        memcpy(cache.cache_files[oldestIndex].content, content, content_size);
        cache.cache_files[oldestIndex].content_size = content_size;
        
        // update timestamp for evicted cache line
        P(&mutex);
        cache.cache_files[oldestIndex].timestamp = timestamp++;
        V(&mutex);
    }
    // cache not full yet
    else {
        // add url to cache
        strcpy(cache.cache_files[cache.using_cache_num].url, url);
        memcpy(cache.cache_files[cache.using_cache_num].content, content, content_size);
        cache.cache_files[cache.using_cache_num].content_size = content_size;
        // update timestamp for recently accessed cache line
        P(&mutex);
        cache.cache_files[cache.using_cache_num].timestamp = timestamp++;
        V(&mutex);
        cache.using_cache_num++;
    }
    // unlock
    V(&w);
    return 0;
}