#include "csapp.h"

#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400
#define MAX_CACHE_NUM 10

typedef char string[MAXLINE];

typedef struct{
    string url;     // shows the path of the cache file
    char content[MAX_OBJECT_SIZE];      // stores files byte by byte
    int content_size;       
    int timestamp;
} cache_file_t;

typedef struct{
    int using_cache_num;    // represents the number of caches currently being used, used to quickly find vacant slots
    cache_file_t cache_files[MAX_CACHE_NUM];    // used to store cache files
} cache_t;


// self-defined functions
void init_cache();                              // initialises the cache, setting using_cache_num to 0
int query_cache(rio_t* rio_p, string url);      // used to check if queried url exists in cache, if so return 1 and return to client side else 0
int add_cache(string url, char* content, int content_size);     // adds a cache file to the cache, if cache is full evict using LRU