/*
 * mm-naive.c - The fastest, least memory-efficient malloc package.
 * 
 * In this naive approach, a block is allocated by simply incrementing
 * the brk pointer.  A block is pure payload. There are no headers or
 * footers.  Blocks are never coalesced or reused. Realloc is
 * implemented directly using mm_malloc and mm_free.
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>

#include "mm.h"
#include "memlib.h"

/*********************************************************
 * NOTE TO STUDENTS: Before you do anything else, please
 * provide your team information in the following struct.
 ********************************************************/
team_t team = {
    /* Team name */
    "ateam",
    /* First member's full name */
    "Harry Bovik",
    /* First member's email address */
    "bovik@cs.cmu.edu",
    /* Second member's full name (leave blank if none) */
    "",
    /* Second member's email address (leave blank if none) */
    ""
};

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8

/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(size) (((size) + (ALIGNMENT-1)) & ~0x7)


#define SIZE_T_SIZE (ALIGN(sizeof(size_t)))




/* self-defined macros for segregated free list*/
// functions that return the min and max values
#define MIN(x,y) ((x)>(y) ? (y) : (x))
#define MAX(x,y) ((x)<(y) ? (y) : (x))

// size of a word is 4 bytes
#define WSIZE 4
#define DSIZE 8

// the size when heap expands
#define EXPANDSIZE (1<<12)

// packs block meta data into a single word
#define PACK(size, alloc) ((size) | (alloc))    // packs metadata about whether it is allocated or not
#define PACK_MORE(size, prev_alloc, alloc) ((size)|(prev_alloc)|(alloc))   // packs more metadata, is the previous block allocated

// read and write values from specific memory addresses, useful for accessing header and footer of memory blocks
#define READ_MEM(ptr) (*(unsigned*) (ptr))
#define WRITE_MEM(ptr, val) (*(unsigned*)(ptr) = val)

// get block size and allocation information
#define GET_SIZE(ptr)       (READ_MEM(ptr) & ~0x7)
#define GET_ALLOC(ptr)      (READ_MEM(ptr) & 0x1)
#define GET_PREV_ALLOC(ptr) (READ_MEM(ptr) & 0x2)
#define SET_ALLOC(ptr)      (READ_MEM(ptr) |= 0x1)
#define SET_FREE(ptr)       (READ_MEM(ptr) &= ~0x1)
#define SET_PREV_ALLOC(ptr) (READ_MEM(ptr) |= 0x2)
#define SET_PREV_FREE(ptr)  (READ_MEM(ptr) &= ~0x2)

// get pointers to the headers and footers of a block
#define HEADER_PTR(blk_ptr) ((char *)(blk_ptr)-WSIZE)
#define FOOTER_PTR(blk_ptr) ((char *)(blk_ptr)+GET_SIZE(HEADER_PTR(blk_ptr))-DSIZE)

// get pointers to previous and next blocks
#define PREV_PTR(blk_ptr)   ((char*)(blk_ptr)-GET_SIZE((char*)(blk_ptr)-DSIZE))
#define NEXT_PTR(blk_ptr)   ((char*)(blk_ptr)+GET_SIZE(HEADER_PTR(blk_ptr)))

/* Global Variables*/
// pointing to the starting position of the heap
static char* heap_start = 0;
// array of pointers to lists
static char** free_lists;

// the number of free lists
#define FREE_LIST_COUNT 15

/* macros to help traverse the lists*/
#define PREV(blk_ptr)            ((char*)(mem_heap_lo()+*(unsigned*)(blk_ptr)))
#define NEXT(blk_ptr)            ((char*)(mem_heap_lo()+*(unsigned*)(blk_ptr+WSIZE)))
#define SET_PREV(blk_ptr, val)   (*(unsigned*)(blk_ptr)=((unsigned)(long)val))
#define SET_NEXT(blk_ptr, val)   (*(unsigned*)((char*)blk_ptr+WSIZE)=((unsigned)(long)val))

// check if pointers are aligned to 8 bytes
#define IS_ALIGNED(ptr) (ALIGN(ptr)==(size_t)ptr)
// check if current free list node is in the range of the current list it is in
static inline void get_range(size_t index);
static size_t low_range;
static size_t high_range;
// helper function prototypes
static inline void* expand(size_t words); // expands the heap
static inline void* merge(void* bp, size_t size);   // merges free blocks around bp to form larger free blocks
static inline size_t get_index(size_t size);    // calculates index of segregated list based on block size
static inline size_t resize(size_t size); // adjusts the allocation size
static inline void* find_fit(size_t size);
static inline void place(void* bp, size_t size); // allocates memory of size at location pointed to by bp
static inline void insert(void* bp, size_t size);// insert a block into segregated list
static inline void delete(void* bp); // deletes a block from the segregated list

/* 
 * mm_init - initialize the malloc package.
 * such as allocating initial heap area
 * return value should be -1 if a problem occured
 * and 0 otherwise
 */
int mm_init(void)
{
    //setting up the pointers to all the lists
    int i = 0;
    free_lists = mem_heap_lo();
    while(i < FREE_LIST_COUNT){
        if ((heap_start = mem_sbrk(DSIZE))==(void*)-1) return -1;
        free_lists[i] = mem_heap_lo();
        i++;
    }


    // heap extended another 16 bytes for prologue and epilogue blocks
    if ((heap_start = mem_sbrk(2*DSIZE))==(void*)-1) return -1;
    
    // empty word to align with starting block header
    WRITE_MEM(heap_start, 0);
    // prologue block header
    WRITE_MEM(heap_start+(1*WSIZE), PACK(DSIZE, 1));
    // prologue block footer
    WRITE_MEM(heap_start+(2*WSIZE), PACK(DSIZE, 1));
    // epilogue block header
    WRITE_MEM(heap_start+(3*WSIZE), PACK(0, 3));
    heap_start += DSIZE;

    // expand the heap with more memory for future allocations
    if (expand(EXPANDSIZE/WSIZE)==NULL){
        return -1;
    }
    return 0;
}

/* 
 * mm_malloc - Allocate a block by incrementing the brk pointer.
 * Always allocate a block whose size is a multiple of the alignment. Aligns to 8 bytes
 * entire allocated block should lie within the heap region and should not overlap
 */
void *mm_malloc(size_t size)
{
    size_t adjusted_size;
    size_t extend_size;
    char* blk_ptr;

    // memory uninitialised
    if (!heap_start){
        mm_init();
    }
    // invalid request
    if (!size) return NULL;

    size = adjust_alloc_size(size);
    // if size is less than DSIZE just need 2*DSIZE,
    // another left for the header and footers
    if (size <= DSIZE){
        adjusted_size = 2*DSIZE;
    } else {
        adjusted_size = DSIZE*((size+(WSIZE)+(DSIZE-1))/DSIZE); // important algorithm
    }

    // requested space available
    if ((blk_ptr = find_fit(adjusted_size)) != NULL){
        place(blk_ptr, adjusted_size);
        return blk_ptr;
    }

    // requested space unavailable
    extend_size = MAX(adjusted_size, EXPANDSIZE);
    if ((blk_ptr = expand(extend_size/WSIZE))==NULL){
        return NULL;
    }
    place(blk_ptr, adjusted_size);
    return blk_ptr;
}

/*
 * mm_free - Freeing a block does nothing.
 * only guaranteed to work when passed pointer was
 * returned by an earlier call to malloc or realloc
 * and has not yet been freed
 */
void mm_free(void *ptr)
{
    if (!ptr) return;
    if (!heap_start) {
        mm_init();
        return;
    }

    // get sizes for current block and previous
    // allocated block
    size_t cur_size = GET_SIZE(HEADER_PTR(ptr));
    size_t prev_alloc = GET_PREV_ALLOC(HEADER_PTR(ptr));
    // setting header and footer for newly freed
    WRITE_MEM(HEADER_PTR(ptr),PACK_MORE(cur_size, prev_alloc, 0));
    WRITE_MEM(FOOTER_PTR(ptr),PACK_MORE(cur_size, prev_alloc, 0));

    merge(ptr, cur_size);
}

/*
 * mm_realloc - Implemented simply in terms of mm_malloc and mm_free
 * constraints:
 * 1. ptr is null equivalent to mm_malloc
 * 2. size is 0 equivalent to mm_realloc
 * 3. ptr is not NUll must have been returned by previous
 * calls to malloc and realloc
 * 4. contents of the new block are the same as those of the old ptr block
 * up to the minimum of the new and old sizes. Everything else is uninitialised
 */
void *mm_realloc(void *ptr, size_t size)
{
    size_t cpysize;
    void* newptr;

    if (!size){
        free(ptr);
        return 0;
    }

    if (!ptr){
        return malloc(size);
    }

    newptr = malloc(size);

    if (!newptr) return 0;

    cpysize = MIN(GET_SIZE(HEADER_PTR(ptr)), size);
    memcpy(newptr, ptr, cpysize);

    free(ptr);

    return newptr;
}




// helper functions used above
static inline void* expand(size_t words){
    char* blk_ptr;
    size_t size;

    // to ensure alignment
    size = (words%2) ? (words+1) * WSIZE : words * WSIZE;

    // newly expand a block
    if ((long)(blk_ptr = mem_sbrk(size))==-1){
        return NULL;
    }

    // Initialise new free block header and footer
    size_t prev_alloc = GET_PREV_ALLOC(HEADER_PTR(blk_ptr));
    WRITE_MEM(HEADER_PTR(blk_ptr), PACK_MORE(size, prev_alloc, 0));
    WRITE_MEM(FOOTER_PTR(blk_ptr), PACK_MORE(size, prev_alloc, 0));

    // Initialise new epilogue block 
    WRITE_MEM(HEADER_PTR(NEXT(blk_ptr)), PACK(0, 1));
    return merge(blk_ptr, size);
}

/*
 * merges neighboring free blocks
 * the allocation flag for the previous block of the 
 * allocated block after the merged free block will be set
 */
static inline void* merge(void* blk_ptr, size_t size){
    // checks if previous and next blocks are allocated or not
    size_t prev_alloc = GET_PREV_ALLOC(HEADER_PTR(blk_ptr));
    size_t next_alloc = GET_ALLOC(HEADER_PTR(blk_ptr));

    // previous and next both are allocated
    if (prev_alloc && next_alloc){
        SET_PREV_FREE(HEADER_PTR(NEXT_PTR(blk_ptr)));
    } 
    // previous allocated and next free
    else if (prev_alloc && !next_alloc){
        delete(NEXT_PTR(blk_ptr));
        size += GET_SIZE(HEADER_PTR(NEXT_PTR(blk_ptr)));
        WRITE_MEM(HEADER_PTR(blk_ptr), PACK_MORE(size, 2, 0));
        WRITE_MEM(FOOTER_PTR(blk_ptr), PACK_MORE(size, 2, 0));
    }
    // previous free next allocated
    else if (!prev_alloc && next_alloc){
        delete(PREV_PTR(blk_ptr));
        SET_PREV_FREE(HEADER_PTR(NEXT_PTR(blk_ptr)));
        size += GET_SIZE(HEADER_PTR(PREV_PTR(blk_ptr)));
        size_t prev_prev_alloc = GET_PREV_ALLOC(HEADER_PTR(PREV_PTR(blk_ptr)));
        WRITE_MEM(HEADER_PTR(PREV_PTR(blk_ptr)), PACK_MORE(size, prev_prev_alloc, 0));
        WRITE_MEM(FOOTER_PTR(blk_ptr), PACK_MORE(size, prev_prev_alloc, 0));
    }
    else {
        delete(PREV_PTR(blk_ptr));
        delete(NEXT_PTR(blk_ptr));
        size += (GET_SIZE(HEADER_PTR(PREV_PTR(blk_ptr)))) + GET_SIZE(HEADER_PTR(NEXT_PTR(blk_ptr)));
        size_t prev_prev_alloc = GET_PREV_ALLOC(HEADER_PTR(PREV_PTR(blk_ptr)));
        WRITE_MEM(HEADER_PTR(blk_ptr), PACK_MORE(size, prev_prev_alloc, 0));
        WRITE_MEM(FOOTER_PTR(blk_ptr), PACK_MORE(size, prev_prev_alloc, 0));
        blk_ptr = PREV_PTR(blk_ptr);
    }
    insert(blk_ptr, size);
    return blk_ptr;
}

// gets list index based on block size
// need to get thresholds by writing your own trace file
static inline size_t get_index(size_t size){
    static const size_t thresholds[] = {24, 32, 64, 80, 120, 240, 480, 960, 1920, 3840, 7680, 15360, 30720, 61440};
    size_t i;

    for (i = 0; i < sizeof(thresholds)/sizeof(thresholds[0]); i++){
        if (size <= thresholds[i]){
            return i;
        }
    }

    return sizeof(thresholds)/sizeof(thresholds[0]);
}

// gets the range of free list according to freelist index
static inline void get_range(size_t index){
    static const size_t low_ranges[] = {8, 24, 32, 64, 80, 120, 240, 480, 960, 1920, 3840, 7680, 15360, 30720, 61440};
    static const size_t hi_ranges[] = {24, 32, 64, 80, 120, 240, 480, 960, 1920, 3840, 7680, 15360, 30720, 61440, 0x7fffffff};

    low_range = low_ranges[index];
    high_range = hi_ranges[index];
}


// traverses the list and finds the first fit
static inline void* find_fit(size_t size){
    int index = get_index(size);
    char* blk_ptr;

    for (; index < FREE_LIST_COUNT; index++){
        for (blk_ptr = free_lists[index]; blk_ptr != mem_heap_lo(); blk_ptr = NEXT(blk_ptr)){
            int remaining_space = GET_SIZE(HEADER_PTR(blk_ptr))-size;
            if (remaining_space >= 0){
                return blk_ptr;
            }
        }
    }
    return NULL;
}


static inline void place(void* blk_ptr, size_t size){
    size_t cur_size = GET_SIZE(HEADER_PTR(blk_ptr));
    size_t spare = cur_size -size;

    delete(blk_ptr);
    // spare size smaller than smallest
    // free block available, don't separate it out
    if (spare < 2 * DSIZE){
        SET_ALLOC(HEADER_PTR(blk_ptr));
        SET_PREV_ALLOC(NEXT_PTR(blk_ptr));
        if (!GET_ALLOC(HEADER(NEXT_PTR(blk_ptr)))){
            SET_PREV_ALLOC(FOOTER_PTR(NEXT_PTR(blk_ptr)));
        }
    }
    else {
        WRITE_MEM(HEADER_PTR(blk_ptr), PACK_MORE(size, GET_PREV_ALLOC(blk_ptr), 1));
        WRITE_MEM(HEADER_PTR(blk_ptr), PACK_ALL(spare, 2, 0));
        WRITE_MEM(HEADER_PTR(blk_ptr), PACK_MORE(spare, 2, 0));

        insert(NEXT_PTR(blk_ptr), spare);
    }
}

// inserts a node into the linked list
// uses the LIFO policy, insert into the head of the ll and allocate the closest
static inline void insert(void* blk_ptr, size_t size){
    size_t index = get_index(size);
    char* cur = free_lists[index];
    free_lists[index] = blk_ptr;
    if (cur != mem_heap_lo()){
        SET_PREV(blk_ptr, NULL);
        SET_NEXT(blk_ptr, cur);
        SET_PREV(cur, blk_ptr);
    } else {
        SET_PREV(blk_ptr, NULL);
        SET_NEXT(blk_ptr, NULL);
    }
}

// delete a node from the linked list
static inline void delete(void* blk_ptr){
    size_t size = GET_SIZE(HEADER_PTR(blk_ptr));
    size_t index = get_index(size);
    char* prev = PREV(blk_ptr);
    char* next = NEXT(blk_ptr);

    // head node
    if (prev == mem_heap_lo()){
        free_lists[index] = next;
        if (next != mem_heap_lo()){
            SET_PREV(next, NULL);
        }
    } 
    // any other node
    else {
        SET_NEXT(prev, next);
        if (next != mem_heap_lo()){
            SET_PREV(next, prev);
        }
    }
}